from clientServerSocketThread import Server 

server = Server()
server.run()
print "Terminated"
