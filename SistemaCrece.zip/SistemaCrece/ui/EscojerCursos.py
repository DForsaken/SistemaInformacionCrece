# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'EscojerCursos.ui'
#
# Created: Sun Jun 16 14:13:25 2013
#      by: PyQt4 UI code generator 4.10
#
# WARNING! All changes made in this file will be lost!

